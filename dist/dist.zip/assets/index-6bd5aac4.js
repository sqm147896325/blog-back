import{_ as e,o as t,g as n}from"./index-39d3125b.js";const o={name:"AppList"};function s(a,c,p,r,_,i){return t(),n("div",null," appList ")}const f=e(o,[["render",s]]);export{f as default};
