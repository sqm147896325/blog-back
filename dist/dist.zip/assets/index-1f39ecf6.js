import{_ as e,o as t,g as n}from"./index-c783bc42.js";const o={name:"AppList"};function s(a,c,p,r,_,i){return t(),n("div",null," appList ")}const f=e(o,[["render",s]]);export{f as default};
